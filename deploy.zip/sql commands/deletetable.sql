-- -- SQLite
-- DROP TABLE files

DELETE FROM posts WHERE class = "Precalculus"
